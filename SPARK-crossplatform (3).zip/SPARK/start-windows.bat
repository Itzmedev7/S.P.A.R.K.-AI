@echo off
REM Double-click this to run S.P.A.R.K. AI on Windows.
cd /d "%~dp0"
where py >nul 2>nul && (py -3 serve.py %* & goto :eof)
where python >nul 2>nul && (python serve.py %* & goto :eof)
echo.
echo   Python 3 was not found.
echo   Install it from https://www.python.org/downloads/ (tick "Add to PATH"),
echo   or just open index.html in your browser - it works there too, but the
echo   browser will not save your chats.
echo.
pause
