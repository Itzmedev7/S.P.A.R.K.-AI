#!/bin/sh
# Run S.P.A.R.K. AI on macOS, Linux or BSD.  ./start-mac-linux.sh
cd "$(dirname "$0")" || exit 1
for py in python3 python; do
  if command -v "$py" >/dev/null 2>&1; then exec "$py" serve.py "$@"; fi
done
echo "Python 3 was not found. Install it, or open index.html directly"
echo "(that works, but the browser will not save your chats)."
exit 1
