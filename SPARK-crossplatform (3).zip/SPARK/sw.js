/* S.P.A.R.K. AI service worker.
   Caches the app shell so it opens with no network on any OS, and keeps the two
   external assets (fonts, KaTeX) once they have been fetched successfully.
   Bump CACHE whenever index.html changes so browsers pick the new copy up. */

const CACHE = 'spark-v7';

const SHELL = [
  './',
  './index.html',
  './manifest.webmanifest',
  './icon-256.png'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE)
      .then(c => c.addAll(SHELL))
      .then(() => self.skipWaiting())
      .catch(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;                     // never touch API calls

  const url = new URL(req.url);

  // Model providers must always go to the network, never to a cache.
  if (/api\.openai\.com|generativelanguage\.googleapis\.com/.test(url.href)) return;

  // The page itself: network first so edits show up, cache as the offline fallback.
  if (req.mode === 'navigate') {
    e.respondWith(
      fetch(req)
        .then(res => {
          const copy = res.clone();
          caches.open(CACHE).then(c => c.put('./index.html', copy)).catch(() => {});
          return res;
        })
        .catch(() => caches.match('./index.html').then(r => r || caches.match('./')))
    );
    return;
  }

  // Everything else (icon, manifest, fonts, KaTeX): cache first, fill in behind.
  e.respondWith(
    caches.match(req).then(hit => hit || fetch(req).then(res => {
      if (res && (res.ok || res.type === 'opaque')) {
        const copy = res.clone();
        caches.open(CACHE).then(c => c.put(req, copy)).catch(() => {});
      }
      return res;
    }).catch(() => hit))
  );
});
