#!/usr/bin/env python3
"""Serve S.P.A.R.K. AI on this machine.

Works on Windows, macOS, Linux, BSD and anything else with Python 3.7+ --
no packages to install. Serving over http (rather than opening the file
directly) is what unlocks three things the browser refuses to give a
file:// page: saved chats, offline use, and the Install button.

    python3 serve.py            # open on this computer
    python3 serve.py --port 9000
    python3 serve.py --no-open  # don't launch a browser

Your phone or tablet can open the same app over the LAN -- the address is
printed when the server starts.
"""

import argparse
import http.server
import os
import socket
import socketserver
import sys
import threading
import webbrowser

ROOT = os.path.dirname(os.path.abspath(__file__))


class Handler(http.server.SimpleHTTPRequestHandler):
    # Windows reads MIME types from the registry, where .webmanifest and
    # sometimes .js are wrong or missing. Pin them so the app installs there too.
    extensions_map = dict(http.server.SimpleHTTPRequestHandler.extensions_map)
    extensions_map.update({
        '.webmanifest': 'application/manifest+json',
        '.js': 'text/javascript',
        '.mjs': 'text/javascript',
        '.json': 'application/json',
        '.html': 'text/html',
        '.svg': 'image/svg+xml',
        '.png': 'image/png',
        '': 'application/octet-stream',
    })

    def __init__(self, *a, **kw):
        super().__init__(*a, directory=ROOT, **kw)

    def end_headers(self):
        # Never let a browser hold on to a stale copy of the app.
        self.send_header('Cache-Control', 'no-cache')
        self.send_header('Service-Worker-Allowed', '/')
        super().end_headers()

    def log_message(self, fmt, *args):
        pass  # keep the terminal quiet


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def lan_address():
    """Best guess at this machine's address on the local network."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))     # no packet is actually sent
        return s.getsockname()[0]
    except Exception:
        return None
    finally:
        s.close()


def main():
    ap = argparse.ArgumentParser(description='Serve S.P.A.R.K. AI locally.')
    ap.add_argument('--port', type=int, default=8765)
    ap.add_argument('--host', default='0.0.0.0',
                    help='use 127.0.0.1 to keep it off the network')
    ap.add_argument('--no-open', action='store_true')
    args = ap.parse_args()

    if not os.path.exists(os.path.join(ROOT, 'index.html')):
        sys.exit('index.html is missing -- run this from the S.P.A.R.K. AI folder.')

    port = args.port
    for attempt in range(20):
        try:
            httpd = Server((args.host, port), Handler)
            break
        except OSError:
            port += 1
    else:
        sys.exit('No free port found between %d and %d.' % (args.port, port))

    local = 'http://localhost:%d/' % port
    print('\n  S.P.A.R.K. AI is running.\n')
    print('  On this computer:  %s' % local)
    lan = lan_address() if args.host == '0.0.0.0' else None
    if lan:
        print('  On your phone:     http://%s:%d/   (same Wi-Fi)' % (lan, port))
    print('\n  Install it: open the address, then use your browser\'s')
    print('  Install / Add to Home Screen option.')
    print('\n  Press Ctrl+C to stop.\n')

    if not args.no_open:
        threading.Timer(0.6, lambda: webbrowser.open(local)).start()

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print('\n  Stopped.\n')
    finally:
        httpd.server_close()


if __name__ == '__main__':
    main()
