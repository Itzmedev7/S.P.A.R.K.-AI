# S.P.A.R.K. AI — running it everywhere

Same folder, every operating system. Keep the files together; `index.html`
looks for the others beside it.

```
index.html              the app
manifest.webmanifest    lets it install as a real app
sw.js                   offline support
icon-256.png            app icon
serve.py                tiny local server (Python 3, no packages)
start-windows.bat       double-click launcher for Windows
start-mac.command       double-click launcher for macOS
start-mac-linux.sh      terminal launcher for macOS / Linux / BSD
```

## Two ways to run it

**Open `index.html` directly.** Works on any OS with any modern browser,
including from a USB stick. Fastest, but the browser treats a `file://` page
as untrusted: Safari and Firefox refuse to save chats there, so the app warns
you and keeps everything in memory for that session only.

**Run the server.** One command, and you get saved chats, offline use, an
Install button, and access from your phone. Recommended.

### Windows
Double-click `start-windows.bat`. If Python is missing it tells you where to
get it — tick *Add python.exe to PATH* during install.

### macOS
Double-click `start-mac.command`. The first time, macOS may block it:
right-click it, choose **Open**, then **Open** again. Python 3 is already on
macOS 12 and later; on older versions run `xcode-select --install`.

### Linux / BSD / ChromeOS (Linux container)
```sh
./start-mac-linux.sh
```

Any of these prints a `http://localhost:8765/` address and opens it.
`Ctrl+C` stops the server.

## Installing it as an app

Open the `http://localhost` address, then:

| OS | How |
|---|---|
| Windows, Linux, ChromeOS | Chrome or Edge → install icon in the address bar |
| macOS | Chrome/Edge → address bar icon. Safari → File → Add to Dock |
| Android | Chrome → menu → Install app |
| iOS / iPadOS | Safari → Share → Add to Home Screen |

It then opens in its own window with no browser chrome, and works with the
network off.

## Using it from your phone

Start the server on your computer and open the second address it prints
(`http://192.168.x.x:8765/`) on a phone on the same Wi-Fi. If nothing loads,
allow Python through your firewall, or run
`python3 serve.py --host 127.0.0.1` to keep it off the network entirely.

## Providers, by platform

**Gemini** and **OpenAI** both work on every OS — the keys stay in that
browser on that device and go only to the provider.

## What makes it portable

- **Storage** falls back to memory when the browser blocks `localStorage`
  (`file://` on Safari, strict private modes), with a banner instead of
  silent data loss.
- **Streaming** uses `fetch` streams where available and falls back to
  waiting for the whole reply on older iOS Safari and WebView shells — the
  answer arrives complete rather than typing itself out.
- **Copy** falls back to `execCommand` outside secure contexts, so the code
  copy buttons work on `file://` and plain-http LAN.
- **Settings dialogs** get a plain-overlay shim on browsers older than
  Safari 15.4 / Firefox 98.
- **Layout** handles notches and home bars via safe-area insets, uses a
  `100vh` fallback where `dvh` is missing, and sets 16px inputs so iOS and
  Android don't zoom on focus.
- **High-contrast** and forced-colors modes on Windows and Linux get visible
  borders.
- **Fonts and KaTeX** load without blocking and are cached after first use,
  so an offline launch still renders — plain text for maths instead of
  typeset, which the boot log reports.

## Updating

Edit `index.html`, then bump `CACHE = 'spark-v1'` in `sw.js` to `v2`. Without
that, installed copies keep serving the old cached page.
